# 任务队列系统

用于跨平台任务分发和状态同步。

## 目录结构

- pending/ - 待处理任务（任何平台可认领）
- completed/ - 已完成任务（归档）

## 任务格式

pending/2026-05-22-task-001.md:
```yaml
---
task_id: 2026-05-22-task-001
created_at: 2026-05-22T08:00:00Z
created_by: coze-openclaw
priority: high
type: research
description: 调研 MiMo 平台工具能力
---

## 任务详情
...
```

## 认领任务

1. 读取 pending/ 目录
2. 选择合适的任务
3. 移动到自己的平台执行
4. 完成后移动到 completed/
