# Memory 同步说明

此目录存储 Hermes 的动态记忆，需要在多平台间同步。

## 文件

- MEMORY.md - 当前工作状态、项目进展、关键决策
- updates/ - 每日更新片段（YYYYMMDD.md）
- sync.json - 最后同步时间戳

## 同步策略

### 从 GitHub 拉取（新平台启动时）
1. 读取 sync.json 获取最后同步时间
2. 拉取 MEMORY.md 加载到上下文
3. 检查 updates/ 目录是否有新片段

### 推送到 GitHub（任务完成后）
1. 整理关键更新内容
2. 创建 updates/YYYYMMDD.md
3. 更新 MEMORY.md
4. 更新 sync.json 时间戳
5. 推送到 GitHub

## 冲突解决

如果两边同时修改：
1. 以时间戳最新的为准
2. 保留历史版本在 updates/
3. 合并时人工确认关键决策
