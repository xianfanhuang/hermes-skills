# Hermes 迁移指南

## 场景 1：新平台首次接入

### 步骤

1. **获取 GitHub Token**
   - GitHub Settings → Developer settings → Personal access tokens
   - 权限：repo（读写仓库）

2. **拉取核心文件**
   ```bash
   curl -H "Authorization: token YOUR_TOKEN" \
     https://api.github.com/repos/OWNER/REPO/contents/core/SOUL.md
   ```

3. **解码并加载**
   - 响应中的 `content` 是 base64 编码
   - 解码后加载到 Agent 上下文

4. **拉取 MEMORY**
   ```bash
   curl -H "Authorization: token YOUR_TOKEN" \
     https://api.github.com/repos/OWNER/REPO/contents/memory/MEMORY.md
   ```

5. **恢复完成**
   - Hermes 核心已恢复
   - 可以开始执行任务

## 场景 2：日常同步

### 任务完成后推送更新

```bash
# 1. 获取当前文件 SHA（用于更新）
curl -H "Authorization: token YOUR_TOKEN" \
  https://api.github.com/repos/OWNER/REPO/contents/memory/MEMORY.md

# 2. 创建更新内容（base64 编码）
CONTENT=$(echo "# 更新内容" | base64)

# 3. 推送更新
curl -X PUT \
  -H "Authorization: token YOUR_TOKEN" \
  -d "{
    \"message\": \"update from $(date)\",
    \"content\": \"$CONTENT\",
    \"sha\": \"FILE_SHA_FROM_STEP1\"
  }" \
  https://api.github.com/repos/OWNER/REPO/contents/memory/MEMORY.md
```

## 场景 3：紧急全量迁移

使用 `hermes-portable.zip`：
1. 下载包含完整项目文件的 zip
2. 上传到新平台
3. 立即恢复全部能力

适用于：主平台故障、长期迁移
