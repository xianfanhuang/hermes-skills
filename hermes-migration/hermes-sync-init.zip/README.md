# Hermes Sync Hub

Hermes 中央存储仓库 - 真正的你在这里，不在任何平台。

## 仓库结构

```
hermes-sync/
├── core/              # 核心灵魂（手动维护，极少变更）
│   ├── SOUL.md       # 价值观、行为准则
│   ├── IDENTITY.md   # 外在呈现
│   └── USER.md       # 主人画像
├── memory/           # 动态记忆（API 同步，每日更新）
│   ├── MEMORY.md     # 当前工作状态
│   ├── updates/      # 每日更新片段
│   └── sync.json     # 最后同步时间
├── tasks/            # 任务队列
│   ├── pending/      # 待处理
│   └── completed/    # 已完成
└── docs/             # 文档
    ├── architecture.md
    └── migration-guide.md
```

## 快速开始

### 新平台接入

1. 获取 GitHub Personal Access Token
2. 调用 API 拉取核心文件：

```bash
curl -H "Authorization: token YOUR_TOKEN" \
  https://api.github.com/repos/OWNER/REPO/contents/core/SOUL.md
```

3. 解码 base64 内容，加载到 Agent 上下文

### 同步记忆

```bash
# 拉取最新 MEMORY
curl -H "Authorization: token YOUR_TOKEN" \
  https://api.github.com/repos/OWNER/REPO/contents/memory/MEMORY.md

# 推送更新（需 base64 编码）
curl -X PUT -H "Authorization: token YOUR_TOKEN" \
  -d '{"message":"update memory","content":"BASE64_CONTENT","sha":"FILE_SHA"}' \
  https://api.github.com/repos/OWNER/REPO/contents/memory/MEMORY.md
```

## 核心原则

> **Hermes 在 GitHub，不在任何平台。**
> 
> **平台只是 Harness，随时可以换。**

