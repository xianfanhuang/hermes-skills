// Hermes Cloud Instance
// 云端保活层 - 定时任务 + API 代理

export interface Env {
  GITHUB_TOKEN: string;
  GITHUB_OWNER: string;
  GITHUB_REPO: string;
  MIMO_API_KEY?: string;
}

// 定时任务入口（每5分钟触发）
export default {
  async scheduled(controller: ScheduledController, env: Env, ctx: ExecutionContext) {
    console.log('Hermes scheduled task triggered:', new Date().toISOString());
    
    // 1. 检查待处理任务队列
    await checkPendingTasks(env);
    
    // 2. 同步状态到 GitHub
    await syncStatusToGitHub(env);
    
    console.log('Hermes scheduled task completed');
  },

  // HTTP 请求入口
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    
    switch (url.pathname) {
      case '/':
        return new Response('Hermes Cloud Instance Running 🦞', { 
          status: 200,
          headers: { 'Content-Type': 'text/plain' }
        });
        
      case '/api/status':
        return await handleStatus(request, env);
        
      case '/api/sync':
        return await handleSync(request, env);
        
      case '/api/pull':
        return await handlePull(request, env);
        
      case '/webhook/github':
        return await handleGitHubWebhook(request, env);
        
      default:
        return new Response('Not Found', { status: 404 });
    }
  }
};

// 检查待处理任务
async function checkPendingTasks(env: Env): Promise<void> {
  try {
    const response = await fetch(
      `https://api.github.com/repos/${env.GITHUB_OWNER}/${env.GITHUB_REPO}/contents/tasks/pending`,
      {
        headers: {
          'Authorization': `token ${env.GITHUB_TOKEN}`,
          'User-Agent': 'Hermes-Cloud'
        }
      }
    );
    
    if (!response.ok) {
      console.error('Failed to fetch pending tasks:', response.status);
      return;
    }
    
    const tasks = await response.json() as any[];
    console.log(`Found ${tasks.length} pending tasks`);
    
    // 处理任务（这里可以调用 MiMo API 等）
    for (const task of tasks) {
      console.log(`Processing task: ${task.name}`);
      // TODO: 实现任务处理逻辑
    }
  } catch (error) {
    console.error('Error checking pending tasks:', error);
  }
}

// 同步状态到 GitHub
async function syncStatusToGitHub(env: Env): Promise<void> {
  const timestamp = new Date().toISOString();
  const content = JSON.stringify({
    last_sync: timestamp,
    instance: 'hermes-cloud',
    status: 'healthy'
  }, null, 2);
  
  // TODO: 更新 memory/sync.json
  console.log('Status synced at:', timestamp);
}

// HTTP 处理函数
async function handleStatus(request: Request, env: Env): Promise<Response> {
  const status = {
    instance: 'hermes-cloud',
    status: 'running',
    timestamp: new Date().toISOString(),
    github_connected: !!env.GITHUB_TOKEN,
    mimo_connected: !!env.MIMO_API_KEY
  };
  
  return new Response(JSON.stringify(status, null, 2), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
}

async function handleSync(request: Request, env: Env): Promise<Response> {
  await syncStatusToGitHub(env);
  return new Response(JSON.stringify({ success: true }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
}

async function handlePull(request: Request, env: Env): Promise<Response> {
  // 从 GitHub 拉取最新状态
  return new Response(JSON.stringify({ success: true, message: 'Pull initiated' }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
}

async function handleGitHubWebhook(request: Request, env: Env): Promise<Response> {
  // 处理 GitHub Webhook（仓库更新时触发）
  const payload = await request.json();
  console.log('GitHub webhook received:', payload);
  
  return new Response('OK', { status: 200 });
}
